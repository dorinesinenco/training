package cli;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import shop.Cart;
import shop.Client;
import shop.Product;


//EntityManagerFactory factory = Persistence.createEntityManagerFactory("orm.experiments.organizer");
//EntityManager entityManager = factory.createEntityManager();

//entityManager.getTransaction().begin();
//entityManager.persist(act);
//entityManager.getTransaction().commit();
//entityManager.close();


public class ShopApp {

	static EntityManagerFactory factory;
	static EntityManager entityManager;
	
	public static void main(String[] args) {
	
			// TODO Auto-generated method stub
		init();
		
		//cream un cos
//		Cart c = new Cart(1000.00F);
		entityManager.getTransaction().begin();
		
		// cautam clientu dupa id
		Client client= entityManager.find(Client.class, 8);
	//	Cart c = new Cart(1000.00F);
    //    client.setCart(c); 		
		
		System.out.println("Am gasit clinetul "+client);
//		client.getCart().addProducts(new Product());
//		client.getCart().addProducts(new Product());
//		client.getCart().addProducts(new Product());
//		//		client.setCart(c);
//		 entityManager.persist(client);
		entityManager.getTransaction().commit();
		entityManager.close();
		
		//generateData();
//		Client c1 = new Client();
//		System.out.println(c1);
//		Client c2 = new Client();
//		System.out.println(c2);
//
//		Product p1 = new Product();
//		System.out.println(p1);
//		Product p2 = new Product();
//		System.out.println(c2);

	}
	// initiaza conect cu BD
	public static void init(){
		//entityManager.getTransaction().begin();
		
		factory = Persistence.createEntityManagerFactory("shop.app.hibernate");
		entityManager = factory.createEntityManager();
	}
	 
	//genereaza clienti si date
	public static void generateData(){
		//entityManager.getTransaction().begin();
		for (int c=1; c<=7; c++){
			entityManager.getTransaction().begin();
			Client client_obj = new Client(); 
			entityManager.persist(client_obj);
			entityManager.getTransaction().commit();
		}
		for (int p=1; p<=9; p++){
			entityManager.getTransaction().begin();
			Product product_obj = new Product();
			entityManager.persist(product_obj);
			entityManager.getTransaction().commit();
		}
//		entityManager.getTransaction().commit();
		entityManager.close();
	}
	
	
}
