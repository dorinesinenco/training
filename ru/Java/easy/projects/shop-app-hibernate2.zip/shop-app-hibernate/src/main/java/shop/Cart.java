package shop;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;


@Entity
@Table(name="carts")
public class Cart {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private float total;
	
	@ManyToMany(cascade= {CascadeType.ALL})
	@JoinTable(
			name="products_to_carts",
			joinColumns = {@JoinColumn(name="card_id")},
			inverseJoinColumns={@JoinColumn(name="product_id")})
	
	
	private Set<Product> products;
	
//	public int getId() {
//		return id;
//	}
//
//	public void setId(int id) {
//		this.id = id;
//	}

	public Set<Product> getProducts() {
		return products;
	}

	public void addProducts(Product p) {
		this.products.add(p);
	}

	public Cart(){
		super();
	    this.products = new HashSet<Product>();
	}
	
	public Cart(float total) {
		super();
		this.total = total;
	    this.products = new HashSet<Product>();
		
		//this.cart_id = cart_id;
		//this.product_id = product_id;
	}

public float getTotal() {
		return total;
	}

	public void setTotal(float total) {
		this.total = total;
	}

	//	public int getProduct_id() {
//		return product_id;
//	}
//	public void setProduct_id(int product_id) {
//		this.product_id = product_id;
//	}
	@Override
	public String toString() {
		return "Cast [cart_id=" +"]";
	}

	
	
}
