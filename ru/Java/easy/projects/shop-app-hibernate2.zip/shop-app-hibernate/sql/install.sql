-- tabelul cu produse
CREATE TABLE products (
id INT(9) NOT NULL PRIMARY KEY AUTO_INCREMENT,
name VARCHAR(100) NOT NULL,
quantity INT(3) NOT NULL,
price DECIMAL(10,2) NOT NULL
);

-- tabelul leaga produse de cos
CREATE TABLE products_to_carts (
cart_id  INT(9) NOT NULL ,
product_id INT(9) NOT NULL
);


-- tabelul cu carts -cosul
CREATE TABLE carts (
id INT(9) NOT NULL PRIMARY KEY AUTO_INCREMENT,
total DECIMAL(10,2) NOT NULL,
client_id INT(9) NOT NULL UNIQUE
);

-- tabelul cu clienti
CREATE TABLE clients (
id INT(9) NOT NULL PRIMARY KEY AUTO_INCREMENT,
fullname VARCHAR(100) NOT NULL,
card_id INT(9) NOT NULL UNIQUE
);

