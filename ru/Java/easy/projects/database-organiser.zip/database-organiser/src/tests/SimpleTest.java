package tests;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SimpleTest {

	public static void main(String[] args) {
		
		
		
		// a) deschidem o conexiune cu baza de date
		Connection link;
		try {
			link = DriverManager.getConnection(
					"jdbc:mysql://192.168.0.169/organizer_162?useSSL=false", // adresa bazei de date
					"root",
					"root"
			);
		
		Statement stmt = link.createStatement();
		stmt.executeUpdate(
	    		"DROP TABLE IF EXISTS activities;"
	    );

		stmt.executeUpdate(
	    		"CREATE TABLE activities("
	    		+ "id INT(10) PRIMARY KEY AUTO_INCREMENT NOT NULL,"
	    		+ "title VARCHAR(100),"
	    		+ "from_ DATE,"
	    		+ "to_ DATE,"
	    		+ "state TINYINT(1),"
	    		+ "location VARCHAR(30)"
	    		+ ");"
	    );
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		//e.printStackTrace();
		System.out.println(e.getMessage());
	}
	  
	}
}