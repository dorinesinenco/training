package main;

import java.util.Scanner;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;

public class App {
	private static Connection link;
	
	public static void main(String[] args){
		int option = -1;
		Scanner in = new Scanner(System.in);
		
		connect();
		
		while(option!=0){
			System.out.println("###################");
			System.out.println("1. Instal");
			System.out.println("2. Add Activity");
			System.out.println("3. Show Activities");
			System.out.println("0. Exit");
			System.out.println("###################");
			System.out.println(">>");
			option = in.nextInt();
			
			
			if (option == 1){
				System.err.println("ACEASTA VA PIERDE DATELE");
				System.err.println("continue DA/NU");
				if (in.next().equals("da")) {
				install();
				System.out.println("INSTALAREA - OK");
				}
				else {
					System.err.println("N-ati confirmat");
				}
					
			}
			if (option == 2){
				System.err.println("SE ADAUGA DATELE");
				//ystem.err.println("continue DA/NU");
				//if (in.next().equals("da")) {
					addActivity();
				//System.out.println("INSTALAREA - OK");
				//}
				//else {
				//	System.err.println("N-ati confirmat");
				//}
					
			}
			if (option == 3){
				showActivities();
			}

			
		}
	}		
		public static void install(){
			try{
			Statement stmt = link.createStatement();
			stmt.executeUpdate(
		    		"DROP TABLE IF EXISTS activities;"
		    );

			stmt.executeUpdate(
		    		"CREATE TABLE activities("
		    		+ "id INT(10) PRIMARY KEY AUTO_INCREMENT NOT NULL,"
		    		+ "title VARCHAR(100),"
		    		+ "from_ DATE,"
		    		+ "to_ DATE,"
		    		+ "state TINYINT(1),"
		    		+ "location VARCHAR(30)"
		    		+ ");"
		    );
			}
			catch (SQLException e){
				System.err.println(">>> EROARE LA INTALARE CU BD<<<");
				System.err.println(e.getMessage());
				System.err.println("HELLO");
			}

		}
		public static void connect() {
			try {
				link = DriverManager.getConnection(
						"jdbc:mysql://192.168.0.169/organizer_162?useSSL=false", // adresa bazei de date
						"root",
						"root"
				);
						
			}
			catch(SQLException e){ 
				System.err.println(">>> EROARE LA CONECT CU BD<<<");
				System.err.println(e.getMessage());
			}
			}
		public static void executeSQL(String query,String[] params){
			PreparedStatement stmt;
			try{
				stmt = link.prepareStatement(query);
				stmt.setString(1, params[0]);
				stmt.setString(2, params[1]);
				stmt.setString(3, params[2]);
				stmt.executeUpdate();
				
			}
			catch(SQLException e){
				System.err.println("EROARE LA ADD");
				System.err.println(e.getMessage());
			}
			
		}
		
		// adauga activ
		public static void addActivity(){
			Scanner in = new Scanner(System.in);
			System.out.println(">>>ADD<<<");
			System.out.println("Denumirea:");
			String name= in.nextLine();
			System.out.println(" Data From:");
			String date_from = in.next();
			System.out.println("Localitate:");
			in.nextLine(); // eliminam enter-ul ramas de la nextLine
			String location= in.nextLine();
		
			// cum de utilizat Setparameter()
			String sql = "INSERT INTO activities(title,from_,location)"
					+"VALUES("
					+"?,"
					+"?,"
					+"?"
					+");";
			
			System.out.println(sql);
			executeSQL(sql, new String[] {name,date_from,location});
		}
			
		public static void showActivities(){
			PreparedStatement stmt;
			try{
				stmt = link.prepareStatement("SELECT * FROM activities;");
				ResultSet data = stmt.executeQuery();
				while (data.next()){
				System.out.println(data.getString("title"));
				System.out.println(data.getString("from_"));
				}
				
			}
			catch(SQLException e){
				System.err.println("EROARE LA CITIRE");
				System.err.println(e.getMessage());
			}
		
			
			
		}
	/*	public static void addActivity_I(){
			Scanner in = new Scanner(System.in);
			System.out.println(">>>ADD<<<");
			System.out.println("Denumirea:");
			String name= in.nextLine();
			System.out.println(" Data From:");
			String date_from = in.next();
			System.out.println("Localitate:");
			in.nextLine(); // eliminam enter-ul ramas de la nextLine
			String location= in.nextLine();
		
			// cum de utilizat Setparameter()
			String sql = "INSERT INTO activities(title,from_,location)"
					+"VALUES("
					+"'"+name+"',"
					+"'"+date_from+"',"
					+"'"+location+"'"
					+");";
			
			System.out.println(sql);
			executeSQL(sql);
		}
			
		
		
		
*/
	}  //main

   //App
