package shop;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;


@Entity
public class Cart {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	
	private int cart_id;
	private int product_id;
	public Cart(int cart_id, int product_id) {
		super();
		this.cart_id = cart_id;
		this.product_id = product_id;
	}
	public int getCart_id() {
		return cart_id;
	}
	public void setCart_id(int cart_id) {
		this.cart_id = cart_id;
	}
	public int getProduct_id() {
		return product_id;
	}
	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}
	@Override
	public String toString() {
		return "Cast [cart_id=" + cart_id + ", product_id=" + product_id + "]";
	}

	
	
}
