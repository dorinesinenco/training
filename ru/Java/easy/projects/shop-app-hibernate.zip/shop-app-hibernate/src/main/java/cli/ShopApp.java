package cli;

import shop.Client;
import shop.Product;

public class ShopApp {

	public static void main(String[] args) {
	
			// TODO Auto-generated method stub
		Client c1 = new Client();
		System.out.println(c1);
		Client c2 = new Client();
		System.out.println(c2);

		Product p1 = new Product();
		System.out.println(p1);
		Product p2 = new Product();
		System.out.println(c2);

	}

	
	
}
