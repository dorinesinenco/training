package shop;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.github.javafaker.Faker;

@Entity
public class Client {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)



	private int id;
	private String fullname;
	private int card_id;
	
	
	
	public Client() {
	//	super();
		//this.id = id;
		Faker f= new Faker();
		this.fullname = f.name().fullName();
		//this.card_id = card_id;
	}
	
	public Client(int id, String fullname, int card_id) {
		//super();
		this.id = id;
		this.fullname = fullname;
		this.card_id = card_id;
	}
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFullname() {
		return fullname;
	}
	public void setFullname(String fullname) {
		this.fullname = fullname;
	}
	public int getCard_id() {
		return card_id;
	}
	public void setCard_id(int card_id) {
		this.card_id = card_id;
	}
	@Override
	public String toString() {
		return "Client [id=" + id + ", fullname=" + fullname + ", card_id=" + card_id + "]";
	}

	
}
