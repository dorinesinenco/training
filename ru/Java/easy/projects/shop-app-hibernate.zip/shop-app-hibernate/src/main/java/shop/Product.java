package shop;

import java.util.Locale;

import javax.persistence.Entity;
import javax.persistence.Id;

import com.github.javafaker.Faker;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
@Entity
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String name;
	private int quantity;
	private float price;

	
	public Product() {
		Faker f= new Faker(new Locale("ru"));
		this.name = f.commerce().productName();
		this.quantity = f.number().numberBetween(5, 15);
		this.price = Float.parseFloat(f.commerce().price(100,1000));

		
		
	}

	
	public Product(String name, int quantity, float price) {
		super();
		this.name = name;
		this.quantity = quantity;
		this.price = price;
	}



//	@Override
//	public String toString() {
//		return "----------------------------------------------------------------------------\n"+
//				"Product e=" + id + ", name=" + name + ", quantity=" + quantity+"pret="+price + "]\n"+
//		        "----------------------------------------------------------------------------\n";
//	}
	
	
	
	public int getId() {
		return id;
	}
	@Override
	public String toString() {
		return "Products [id=" + id + ", name=" + name + ", quantity=" + quantity + ", price=" + price + "]";
	}



	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	} 

	

}
