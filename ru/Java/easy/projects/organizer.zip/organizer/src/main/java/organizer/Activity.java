package organizer;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.GenerationType;

@Entity
@Table(name="activities")
public class Activity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	
	private int id;
	private String title;
	private String from_;
	private String to_;
	private int state;
	@Column(name="location")
	private String locality;
	
	
	public Activity(){
		super();
	}
	public Activity(String title, String from_, String to_, int state, String locality) {
		super();
		//this.id = id;
		this.title = title;
		this.from_ = from_;
		this.to_ = to_;
		this.state = state;
		this.locality = locality;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getFrom_() {
		return from_;
	}
	public void setFrom_(String from_) {
		this.from_ = from_;
	}
	public String getTo_() {
		return to_;
	}
	public void setTo_(String to_) {
		this.to_ = to_;
	}
	public int getState() {
		return state;
	}
	public void setState(int state) {
		this.state = state;
	}
	public String getLocality() {
		return locality;
	}
	public void setLocality(String locality) {
		this.locality = locality;
	}
	
	//declaram MAPPINGUL prin anotatii
	
	
	

}
