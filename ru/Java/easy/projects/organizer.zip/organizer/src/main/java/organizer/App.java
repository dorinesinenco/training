package organizer;

		
		import java.util.Scanner;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.EntityManager;

import java.sql.PreparedStatement;
		import java.sql.Connection;
		import java.sql.DriverManager;
		import java.sql.SQLException;
		import java.sql.Statement;
		import java.sql.ResultSet;

		public class App {
			private static Connection link;
			
			public static void main(String[] args){
				int option = -1;
				Scanner in = new Scanner(System.in);
				
//				connect();
				
				while(option!=0){
					System.out.println("###################");
					System.out.println("1. Instal");
					System.out.println("2. Add Activity");
					System.out.println("3. Edit Activities");
					System.out.println("0. Exit");
					System.out.println("###################");
					System.out.println(">>");
					option = in.nextInt();
					
					
					if (option == 1){
						System.err.println("ACEASTA VA PIERDE DATELE");
						System.err.println("continue DA/NU");
						if (in.next().equals("da")) {
	//					install();
						System.out.println("INSTALAREA - OK");
						}
						else {
							System.err.println("N-ati confirmat");
						}
							
					}
					if (option == 2){
						System.err.println("SE ADAUGA DATELE");
						addActivity();
					}
					if (option == 3){
						editActivity();
					}

					
				}
			}
				public static void addActivity(){

					Scanner in = new Scanner(System.in);
					System.out.println(">>>ADD<<<");
					System.out.println("Denumirea:");
					String name= in.nextLine();
					System.out.println(" Data From:");
					String data_from = in.next();
					System.out.println("Localitate:");
					in.nextLine(); // eliminam enter-ul ramas de la nextLine
					String location= in.nextLine();
				
					// cum de utilizat Setparameter()
				/*	String sql = "INSERT INTO activities(title,from_,location)"
							+"VALUES("
							+"?,"
							+"?,"
							+"?"
							+");";
					
					System.out.println(sql);
					executeSQL(sql, new String[] {name,data_from,location});
			    */
				   
					Activity act = new Activity(
							name,
							data_from,
							"2017-01-01",
							0,
							location
							);
					// add ob in bd cu ORM
					EntityManagerFactory factory = Persistence.createEntityManagerFactory("orm.experiments.organizer");
					EntityManager entityManager = factory.createEntityManager();
					
					entityManager.getTransaction().begin();
					entityManager.persist(act);
					entityManager.getTransaction().commit();
					entityManager.close();
				}
					
				public static void editActivity(){

					Scanner in = new Scanner(System.in);
					System.out.println(">>>EDIT ACTIVITY<<<");
					System.out.println("Indica ID:");
					int id= in.nextInt();

					
					// add ob in bd cu ORM
					EntityManagerFactory factory = Persistence.createEntityManagerFactory("orm.experiments.organizer");
					EntityManager entityManager = factory.createEntityManager();
					
					Activity act = entityManager.find(Activity.class,id);
					if (act != null) {
						System.out.println("Titlul activ : "+act.getTitle());
						in.nextLine();
						System.out.println("Titlu nou: ");
						String new_title = in.nextLine();
					    act.setTitle(new_title);
		
					
					
					entityManager.getTransaction().begin();
					entityManager.persist(act);
					entityManager.getTransaction().commit();
					entityManager.close();
				} //edit
				}			
		
				
				
			}		

	


