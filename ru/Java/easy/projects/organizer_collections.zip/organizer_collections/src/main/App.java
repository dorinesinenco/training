package main;
import java.util.Set;
import java.util.HashSet;
import java.util.ArrayList;

import entity.Activity;
import java.util.PriorityQueue;;
public class App {
	public static void main(String[] args){
		
		
		//array simplu
//		Activity[] array_act= {
//				new  Activity("Concert de pian. Enescu","2017-10-31",0,"Chisinau"),
//				new  Activity("Concert de vioara. Enescu","2017-10-31",0,"Chisinau"),
//				new  Activity("Concert de pian. Enescu","2017-10-31",0,"Balti"),
//				new  Activity("Concert de vioara. Enescu","2017-10-31",0,"Chisinau"), //dublu adaugat
//					new  Activity("Concert de pian. Enescu","2017-10-31",0,"Cahul")
//		                     };
//		
//		//Activity concert_pian = new  Activity("Concert de pian. Enescu","2017-10-31",0,"Chisinau");
	    
//		Set<Activity> set_activity = new HashSet();
//		set_activity.add(new  Activity("Concert de pian. Enescu","2017-10-31",0,"Chisinau"));
//		set_activity.add(new  Activity("Concert de vioara. Enescu","2017-10-31",0,"Chisinau"));
//		set_activity.add(new  Activity("Concert de pian. Enescu","2017-10-31",0,"Balti"));
//		set_activity.add(new  Activity("Concert de vioara. Enescu","2017-10-31",0,"Chisinau"));
//		set_activity.add(new  Activity("Concert de pian. Enescu","2017-10-31",0,"Cahul"));
//		
//		
		PriorityQueue<Activity> pq_activity = new PriorityQueue();
	
		Set<Activity> set_activity = new HashSet();
		pq_activity.add(new  Activity("Concert de pian. Enescu","2017-10-31",0,"Chisinau"));
		pq_activity.add(new  Activity("Concert de vioara. Enescu","2017-10-31",0,"Chisinau"));
		pq_activity.add(new  Activity("Concert de pian. Enescu","2017-10-31",0,"Balti"));
		pq_activity.add(new  Activity("Concert de vioara. Enescu","2017-10-31",0,"Chisinau"));
		pq_activity.add(new  Activity("Concert de pian. Enescu","2017-10-31",0,"Cahul"));
		//pq_activity.add()
		//System.out.println(concert_pian);
//	 for (Activity a: pq_activity){
//		System.out.println(a);
//		}
		Activity a;
		PriorityQueue<Activity> pq_activity_clone = new PriorityQueue(pq_activity);
		
		while ((a =pq_activity_clone.poll())!=null) {
			System.out.println(a);
		}
		System.out.println("Au ramas "+pq_activity.size());
        Set<Activity> transform_set = new HashSet<Activity>(pq_activity);
   	 for (Activity aa: transform_set){
   		System.out.println(aa);
   		}

     ArrayList<Activity> transform_list = new ArrayList<Activity>(pq_activity);

	}
}
