package main;
import java.util.HashMap;
import java.util.Map;
import entity.Activity;

public class App2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<String,Activity> lista_responsabili = new HashMap();
		lista_responsabili.put("Ion", new  Activity("Concert de pian. Enescu","2017-10-31",0,"Chisinau"));
		lista_responsabili.put("Maria",new  Activity("Concert de vioara. Enescu","2017-10-31",0,"Chisinau"));
		lista_responsabili.put("Ion",new  Activity("Concert de pian. Enescu","2017-10-31",0,"Balti"));
	
		System.out.println("In total : "+lista_responsabili.size());
	
		System.out.println("Maria: "+lista_responsabili.get("Maria"));
		System.out.println("Ion: "+lista_responsabili.get("Ion"));
	
		for(String key:lista_responsabili.keySet()){
				System.out.println(">>>"+key+" are " +lista_responsabili.get(key));
		}

	}
	

}
