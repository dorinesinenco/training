package entity;

public class Borsh implements Comparable<Activity>{
	private int gramaj;
	private float temp;
	public Borsh(int gramaj, float temp) {
		super();
		this.gramaj = gramaj;
		this.temp = temp;
	}
	public int getGramaj() {
		return gramaj;
	}
	public void setGramaj(int gramaj) {
		this.gramaj = gramaj;
	}
	public float getTemp() {
		return temp;
	}
	public void setTemp(float temp) {
		this.temp = temp;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + gramaj;
		result = prime * result + Float.floatToIntBits(temp);
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Borsh other = (Borsh) obj;
		if (gramaj != other.gramaj)
			return false;
		if (Float.floatToIntBits(temp) != Float.floatToIntBits(other.temp))
			return false;
		return true;
	}
	@Override
	public int compareTo(Borsh o) {
	    if (this.gramaj==o.gramaj) { // && o.locality.equals("Balti") ) {
	    	return -1;
	    }
	    else if (this.gramaj>o.gramaj) { //  &&o .locality.equals("Chisinau")) {
		    return 1;
	    }
	    else return 0;

	
	}
	

	
	
}
