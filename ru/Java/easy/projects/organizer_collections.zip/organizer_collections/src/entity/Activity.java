package entity;


public class Activity implements Comparable<Activity>{
	
	//private int id;  //refactoring
	private String title;
	private String start;
	//private String to_;
	private int state;
	private String locality;
	
	
	public Activity(String title, String start, int state, String locality) {
		super();
		//this.id = id;
		this.title = title;
		this.start = start;
		//this.to_ = to_;
		this.state = state;
		this.locality = locality;
	}
	//public int getId() {
	//	return id;
	//}
	//public void setId(int id) {
	//	this.id = id;
	//}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getStart() {
		return start;
	}
	public void setStart(String start) {
		this.start = start;
	}
	//public String getTo_() {
	//	return to_;
	//}
	//public void setTo_(String to_) {
	//	this.to_ = to_;
	//}
	public int getState() {
		return state;
	}
	public void setState(int state) {
		this.state = state;
	}
	public String getLocality() {
		return locality;
	}
	public void setLocality(String locality) {
		this.locality = locality;
	}
	
	@Override
	public String toString() {
		return "----------------------------------------------------------------------------\n"+
				"Activity [title=" + title + ", start=" + start + ", locality=" + locality + "]\n"+
		        "----------------------------------------------------------------------------\n";
	}
	@Override
	public int hashCode() {
		//return result;
		return 1;
	}
	@Override
	public boolean equals(Object obj) {
		boolean result = this.title.equals(((Activity)obj).title)&&this.locality.equals(((Activity)obj).locality); //convertim obj ca acititate
		
		return result;
	}
	@Override
	public int compareTo(Activity o) {
		// TODO Auto-generated method stub
	    if (this.locality.equals("Chisinau") && o.locality.equals("Balti") ) {
	    	return -1;
	    }
	    else if (this.locality.equals("Balti") &&o .locality.equals("Chisinau")) {
		    return 1;
	    }
	    else return 0;
	}

	//declaram MAPPINGUL prin anotatii
	
	
	
	
	

}
