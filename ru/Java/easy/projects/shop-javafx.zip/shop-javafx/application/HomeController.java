package application;

import javafx.fxml.FXML;
import javafx.scene.input.MouseEvent;
import javafx.scene.control.TextField;

public class HomeController {

	@FXML TextField input;

	@FXML 
	public void printHello(MouseEvent event) {
		System.out.println("Salut "+input.getText()+"!");
		
	}
	}

