package application;

import javafx.fxml.FXML;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.control.Label;

public class RegisterController {
	
	@FXML PasswordField password1;
	@FXML PasswordField password2;
	@FXML Label message;

	@FXML 
	public void printHello(MouseEvent event) {
		//System.out.println("Parola1 "+input.getText()+"!");

        String pass1=password1.getText();
        String pass2=password2.getText();
        if (pass1.equals(pass2)) {
        	//System.out.println("Ai introdus corect partola");
        	message.setText("Ai introdus corect partola");
        }
        else {
        	//System.out.println("Partola incorecta");
        	message.setText("Partola incorecta");
        	message.setStyle("-fx-background-color: aqua;");
        }
	}

	}


